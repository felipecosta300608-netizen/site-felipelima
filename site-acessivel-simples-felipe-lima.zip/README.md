# Site Acessível (mínimo) — Felipe Lima

Itens implementados:
- A+/A- (ajuste de `html{ font-size }`)
- Alto contraste (classe `.alto-contraste` no `body`)
- Imagens com `alt`
- ARIA básico (aria-controls, aria-expanded, aria-hidden, role=group)

## Como rodar
1. Abra `index.html` no navegador.
2. Use o menu **Acessibilidade** (A+/A-/Alto contraste) para testar.
3. Confira os textos alternativos das imagens e a semântica.

## Como publicar (GitHub Pages)
- Envie estes arquivos para um repositório.
- Em *Settings → Pages*, use *Deploy from a branch* e branch `main`.
